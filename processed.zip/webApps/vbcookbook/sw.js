'use strict';
const vbScript = {};
globalThis.vbGlobal = {};
const injectVersions = (() => {
  vbScript.version = '2110.0.2';
  vbScript.jetVersion = '10.1.3';
  vbScript.jetCdnPath = 'https://static.oracle.com/cdn/jet/';
  vbScript.workboxVersion = '6.1.5';
  vbScript.workboxCdnPath = 'https://static.oracle.com/cdn/vb/workbox/releases/';
})();
const validateConfig = (() => {
  globalThis.vbInitConfig = {
    JET_URL: 'https://static.oracle.com/cdn/jet/10.1.3',
    JET_CDN_PATH: 'https://static.oracle.com/cdn/jet/10.1.3',
    JET_CDN_VERSION: '',
    DEBUG: false,
    CONTEXT_ROOT: '%{env.vbServer.context}%',
    APP_ID: '%{env.application.id}%',
    APP_VERSION: '%{env.application.version}%',
    APP_URL_PREFIX: 'rt',
    IS_DT_MODE: false,
    VB_SERVER: '%{env.vbServer.url}%',
    APP_PATH: 'webApps/vbcookbook',
    TRACE_CONFIG: {},
    BASE_URL_TOKEN: 'version_1667856030669',
    VB_URL: 'https://static.oracle.com/cdn/vb/2110.0.2',
    VB_CDN_PATH: 'https://static.oracle.com/cdn/vb/2110.0.2',
    PWA_CONFIG: {},
  };
  const isConfigInvalid = () =>
    typeof globalThis.vbInitConfig !== 'object' ||
    globalThis.vbInitConfig === null ||
    Object.getOwnPropertyNames(globalThis.vbInitConfig).length === 0 ||
    typeof globalThis.vbInitConfig.PWA_CONFIG !== 'object' ||
    globalThis.vbInitConfig.PWA_CONFIG === null;
  if (isConfigInvalid()) {
    throw new Error(`Invalid vbInitConfig specified: ${globalThis.vbInitConfig}`);
  }
})();
const addPathsToConfig = (() => {
  const addSlash = (path) => {
    if (path && typeof path === 'string') {
      return path.trim().replace(/\/$|$/, '/');
    }
    return '';
  };
  const config = Object.assign({}, globalThis.vbInitConfig);
  config.vbPath = `${addSlash(config.VB_CDN_PATH)}${config.VB_CDN_VERSION || ''}`;
  const jetVersion = config.JET_CDN_VERSION || '';
  const jetCdnPath = addSlash(config.JET_CDN_PATH) || `${vbScript.jetCdnPath}${vbScript.jetVersion}`;
  config.jetPath = addSlash(`${jetCdnPath}${jetVersion}`);
  const workboxCdnPath = config.WORKBOX_CDN_PATH || vbScript.workboxCdnPath;
  config.workboxCdn = addSlash(`${workboxCdnPath}${vbScript.workboxVersion}`);
  vbScript.config = config;
})();
const importDependencies = (() => {
  importScripts(`${vbScript.config.jetPath}3rdparty/require/require${vbScript.config.DEBUG ? '-debug' : ''}.js`);
  importScripts(`${vbScript.config.workboxCdn}workbox-sw.js`);
  importScripts(`${vbScript.config.vbPath}sw-modules${vbScript.config.DEBUG ? '-debug' : ''}.js`);
})();
const initLogger = (() => {
  if (vbScript.config.DEBUG) {
    globalThis.vbGlobal.logger = console;
  } else {
    globalThis.__WB_DISABLE_DEV_LOGS = true;
    const noopLogger = {info: () => {}, warn: () => {}, error: () => {}, log: () => {}};
    globalThis.vbGlobal.logger = noopLogger;
  }
  vbScript.logger = globalThis.vbGlobal.logger;
})();
const initWorkbox = (() => {
  globalThis.workbox.setConfig({debug: vbScript.config.DEBUG, modulePathPrefix: vbScript.config.workboxCdn});
  globalThis.workbox.loadModule('workbox-core');
  globalThis.workbox.loadModule('workbox-precaching');
  globalThis.workbox.core.setCacheNameDetails({prefix: globalThis.vbInitConfig.PWA_CONFIG.cachePrefix || 'wb-'});
  if (globalThis.vbGlobal.isCachingEnabled(vbScript.config)) {
    globalThis.vbGlobal.precacheController = new globalThis.workbox.precaching.PrecacheController();
    globalThis.vbGlobal.precacheManifest = [];
    const externalManifestLocation = globalThis.vbInitConfig.PWA_CONFIG.precacheManifest;
    if (externalManifestLocation) {
      try {
        importScripts(externalManifestLocation);
        globalThis.vbGlobal.precacheManifest = globalThis.precacheManifest || [];
      } catch (error) {
        vbScript.logger.error(`Importing precache manifest failed with error: ${error}`);
      }
    } else {
      globalThis.vbGlobal.precacheManifest = self.__WB_MANIFEST || [];
    }
    const offlinePage = globalThis.vbGlobal.getOfflinePageUrl(globalThis.vbInitConfig);
    if (globalThis.vbGlobal.precacheManifest.length === 0 && offlinePage) {
      const offlinePageRevision = /*%OFFLINE_PAGE_REVISION%*/ null;
      globalThis.vbGlobal.precacheManifest.push({url: offlinePage, revision: offlinePageRevision});
    }
    globalThis.vbGlobal.precacheController.addToCacheList(globalThis.vbGlobal.precacheManifest);
    globalThis.workbox.precaching.cleanupOutdatedCaches();
    globalThis.vbGlobal.registerRoutingStrategies(vbScript.config);
  }
})();
const initVersion = (() => {
  vbScript.swVersion = {version: vbScript.version, scriptUrl: globalThis.location.href};
  if (globalThis.nonce) {
    vbScript.swVersion.nonce = globalThis.nonce;
  }
  vbScript.getV = () => `version: ${JSON.stringify(vbScript.swVersion, null, 2)}`;
  vbScript.logger.log(`Service worker script loaded, ${vbScript.getV()}`);
  globalThis.vb = Object.assign({}, vbScript.swVersion);
})();
vbScript.getResource = (resource) =>
  new Promise((resolve, reject) => {
    requirejs(
      [resource],
      (loaded) => {
        resolve(loaded);
      },
      (reason) => {
        reject(reason);
      }
    );
  });
vbScript.getLogger = async (level) => {
  if (level || !vbScript.loggerPromise) {
    vbScript.loggerPromise = vbScript.getResource('vbc/private/log').then((Log) => {
      Log.setMinimumLevel(level || 'error');
      globalThis.vbGlobal.logger = Log.getLogger('/sw/sw.js');
      return globalThis.vbGlobal.logger;
    });
  }
  return vbScript.loggerPromise;
};
vbScript.getUtils = async () => {
  if (!vbScript.utilsPromise) {
    vbScript.utilsPromise = vbScript.getResource('vbsw/private/utils');
  }
  return vbScript.utilsPromise;
};
vbScript.getCacheManager = async () => {
  if (!vbScript.cacheManagerPromise) {
    vbScript.cacheManagerPromise = vbScript
      .getResource('sw/private/cacheManager')
      .then((CacheManager) => new CacheManager(vbScript.config));
  }
  return vbScript.cacheManagerPromise;
};
vbScript.initPerformance = () => {
  if (!vbScript.performancePromise) {
    vbScript.performancePromise = vbScript.getResource('vbc/private/performance/performance').then((Performance) => {
      Performance.init(globalThis.vb, vbScript.config.PERFORMANCE_CONFIG);
      vbScript.performance = Performance;
    });
  }
  return vbScript.performancePromise;
};
self.addEventListener('install', async (event) => {
  self.skipWaiting();
  event.waitUntil(
    (async function installImpl() {
      try {
        await vbScript.getLogger();
        vbScript.logger.info(`Service worker install event, ${vbScript.getV()}`);
        if (globalThis.vbGlobal.precacheController) {
          const precacheInstallMark = ['precache.install'];
          await vbScript.initPerformance();
          vbScript.performance.markStart(precacheInstallMark);
          const installResult = await globalThis.vbGlobal.precacheController.install(event);
          vbScript.performance.markEnd(precacheInstallMark);
          vbScript.logger.info('PrecacheController installResult:', installResult, `\n for ${vbScript.getV()}`);
        }
      } catch (error) {
        vbScript.logger.error(`Service worker install failed, ${vbScript.getV()}\n, error: ${error}`);
      }
    })()
  );
});
self.addEventListener('activate', async (event) => {
  event.waitUntil(
    (async function activateImpl() {
      try {
        await vbScript.getLogger();
        vbScript.logger.info(`Service worker activate event, ${vbScript.getV()}`);
        const cm = await vbScript.getCacheManager();
        await cm.deleteStaleCaches();
        if (globalThis.vbGlobal.precacheController) {
          const cleanupResult = await globalThis.vbGlobal.precacheController.activate(event);
          vbScript.logger.info('PrecacheController cleanupResult:', cleanupResult, `\n for ${vbScript.getV()}`);
        }
        self.clients.claim();
      } catch (error) {
        vbScript.logger.error(`Service worker activate failed, ${vbScript.getV()}\n, error: ${error}`);
      }
    })()
  );
});
self.addEventListener('message', async (event) => {
  if (!(event.data && event.data.type)) return;
  await vbScript.getLogger();
  vbScript.logger.info(`Service worker ${vbScript.getV()} received a command: ${event.data.type}`);
  switch (event.data.type) {
    case 'SKIP_WAITING':
      self.skipWaiting();
      break;
    case 'GET_VERSION':
      event.ports[0].postMessage(vbScript.swVersion);
      break;
    case 'SET_LOGGING_LEVEL':
      await vbScript.getLogger(event.data.payload.level);
      break;
    default: {
      vbScript.logger.info(`Service worker message handler did not respond to command: ${event.data.type}`);
    }
  }
});
self.addEventListener('fetch', (event) => {
  if (vbScript.precacheController) {
    const cacheKey = vbScript.precacheController.getCacheKeyForURL(event.request.url);
    if (cacheKey) {
      event.respondWith(caches.match(cacheKey));
    }
  }
});
