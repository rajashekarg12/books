======================================================
Oracle Free Use Terms and Conditions (FUTC) License 
======================================================
https://www.oracle.com/downloads/licenses/oracle-free-license.html
===================================================================

ojdbc8-full.tar.gz - JDBC Thin Driver and Companion JARS
========================================================
This TAR archive (ojdbc8-full.tar.gz) contains the 23.9.0.25.07 release of the Oracle JDBC Thin driver(ojdbc8.jar), the Universal Connection Pool (ucp.jar) and other companion JARs grouped by category. 

(1) ojdbc8.jar (7364220 bytes) - 
(SHA1 Checksum: 0f04adb90d90ac55b8edde797d98fec7024c92ec)
Oracle JDBC Driver compatible with JDK8, JDK11, JDK12, JDK13, JDK14, and JDK15.

(2) ucp.jar (1499354 bytes) - (SHA1 Checksum: 58a621211b80338cbd9d19bf36e18ed3d7e8926b)
Universal Connection Pool classes to be used with ojdbc8.jar -- for performance, scalability, high availability, sharded and multitenant databases.
 
(3) rsi.jar (260580 bytes) - (SHA1 Checksum: 0a54f213c98d2348b29de346d9c1962dfad121bf)
Reactive Streams Ingestion (RSI) 

======================
Security Related JARs
======================
Java applications require some additional jars to use Oracle Wallets. 
You need to use all the three jars while using Oracle Wallets. 

(4) oraclepki.jar (506433 bytes) - (SHA1 Checksum: 07f42561fba5f44d03dbe45e7d7ddd664759a931)
Additional jar required to access Oracle Wallets from Java

=============================
JARs for NLS and XDK support 
=============================
(5) orai18n.jar (1666066 bytes) - (SHA1 Checksum: cc17a3dba5fa992cf9312ded52da9276409b4023) 
Classes for NLS support
(6) xdb.jar (131728 bytes) - (SHA1 Checksum: 8420ccb275d0e1a958b7ccb4d1bc9a62d903ebbb)
Classes to support standard JDBC 4.x java.sql.SQLXML interface 
(7) xmlparserv2.jar (1949516 bytes) - (SHA1 Checksum: b8c4cd6b2c4310c06005595ac5ce7e71d5915f70)
Classes to support standard JDBC 4.x java.sql.SQLXML interface 
(8) xmlparserv2_sans_jaxp_services.jar (1946193 bytes) - (SHA1 Checksum: 76682b7ab8d4f3f8fabcc12070020b1fca2f96e2) 
Classes to support standard JDBC 4.x java.sql.SQLXML interface

====================================================
JARs for Real Application Clusters(RAC), ADG, or DG 
====================================================
(9) ons.jar (155209 bytes) - (SHA1 Checksum: 69484c9ddf6d44a179605e41813e2f0505dd401a)
for use by the pure Java client-side Oracle Notification Services (ONS) daemon
(10) simplefan.jar (32445 bytes) - (SHA1 Checksum: 27d84790ca1886de7b826dd95a17424143c91189)
Java APIs for subscribing to RAC events via ONS; simplefan policy and javadoc

==================================================================
Oracle JDBC and UCP - Javadoc and README
==================================================================

(11) JDBC-Javadoc-23ai.jar (2430851 bytes) - JDBC API Reference 23ai

(12) ucp-Javadoc-23ai.jar (459846 bytes) - UCP Java API Reference 23ai

(13) rsi-Javadoc-23ai.jar (192113 bytes) - RSI Java API Reference 23ai

(14) simplefan-Javadoc-23ai.jar (231615 bytes) - Simplefan API Reference 23ai 

(15) xdb-Javadoc-23ai.jar (2631108 bytes) - XDB API Reference 23ai 

(16) xmlparserv2-Javadoc-23ai.jar (2631108 bytes) - xmlparserv2 API Reference 23ai 

(17) JDBC-Readme.txt: It contains general information about the JDBC driver and bugs that have been fixed in the 23.9.0.25.07 release. 

(18) UCP-Readme.txt: It contains general information about UCP and bugs that are fixed in the 23.9.0.25.07 release. 

=============== Known Problems in the Release 23ai ==================== 

Refer to Bugs-fixed-in-23ai.txt on JDBC download page (https://www.oracle.com/database/technologies/appdev/jdbc-downloads.html) for the list of bugs fixed in the 23ai release.
